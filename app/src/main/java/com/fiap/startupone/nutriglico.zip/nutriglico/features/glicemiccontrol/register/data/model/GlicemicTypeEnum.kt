package com.fiap.startupone.nutriglico.features.glicemiccontrol.register.data.model

enum class GlicemicTypeEnum {
    FAST,
    RANDOM
}